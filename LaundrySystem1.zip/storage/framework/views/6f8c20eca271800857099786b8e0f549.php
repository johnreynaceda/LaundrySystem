<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <?php echo WireUi::directives()->scripts(attributes: []); ?>

    <!-- Scripts -->
    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>

    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="font-sans antialiased">
    <div>

        <div class="w-full mx-auto   2xl:max-w-7xl">
            <div x-data="{ open: false }"
                class="relative flex flex-col w-full p-5 mx-auto bg-main rounded-b-3xl shadow-xl  md:items-center md:justify-between md:flex-row md:px-6 lg:px-10">
                <div class="flex flex-row items-center justify-between lg:justify-start">
                    <a class="text-lg tracking-tight flex space-x-3 items-center text-black uppercase focus:outline-none focus:ring lg:text-2xl"
                        href="/">
                        <?php if (isset($component)) { $__componentOriginal95528eaba12520ffe49a431c848e8d93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal95528eaba12520ffe49a431c848e8d93 = $attributes; } ?>
<?php $component = App\View\Components\Shared\Logo::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Shared\Logo::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal95528eaba12520ffe49a431c848e8d93)): ?>
<?php $attributes = $__attributesOriginal95528eaba12520ffe49a431c848e8d93; ?>
<?php unset($__attributesOriginal95528eaba12520ffe49a431c848e8d93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal95528eaba12520ffe49a431c848e8d93)): ?>
<?php $component = $__componentOriginal95528eaba12520ffe49a431c848e8d93; ?>
<?php unset($__componentOriginal95528eaba12520ffe49a431c848e8d93); ?>
<?php endif; ?>
                        <div>
                            <h1 class="font-bold text-2xl text-white">LAUNDRY</h1>
                            <h1 class="font-bold text-sm leading-3 text-gray-200">Booking System</h1>
                        </div>
                    </a>
                    <button @click="open = !open"
                        class="inline-flex items-center justify-center p-2 text-gray-400 hover:text-black focus:outline-none focus:text-black md:hidden">
                        <svg class="w-6 h-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                            <path :class="{ 'hidden': open, 'inline-flex': !open }" class="inline-flex"
                                stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 6h16M4 12h16M4 18h16"></path>
                            <path :class="{ 'hidden': !open, 'inline-flex': open }" class="hidden"
                                stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
                <nav :class="{ 'flex': open, 'hidden': !open }"
                    class="flex-col items-center flex-grow hidden md:pb-0 md:flex md:justify-end md:flex-row">



                    <div class="inline-flex items-center gap-7 text-white list-none">
                        <?php if(auth()->user()->is_admin == false): ?>
                            <a class="hover:text-gray-300" href="<?php echo e(route('user.dashboard')); ?>">HOME</a>
                        <?php else: ?>
                            <a class="hover:text-gray-300" href="<?php echo e(route('welcome')); ?>">HOME</a>
                        <?php endif; ?>
                        <a class="hover:text-gray-300" href="<?php echo e(route('about')); ?>">ABOUT</a>
                        <a class="hover:text-gray-300" href="<?php echo e(route('pricing')); ?>">PRICING</a>
                        <?php if(auth()->check()): ?>
                            <a class="hover:text-gray-300" href="<?php echo e(route('user.booking')); ?>">MY BOOKING
                                (<?php echo e(\App\Models\Booking::where('user_id', auth()->user()->id)->count()); ?>)</a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="flex items-center border p-2 rounded space-x-2">
                                    <span class="uppercase"><?php echo e(auth()->user()->name); ?></span>
                                    <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92 = $attributes; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['href' => ''.e(route('logout')).'','icon' => 'logout'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'event.preventDefault();
                                this.closest(\'form\').submit();','xs' => true,'class' => 'text-white hover:text-main font-medium']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $attributes = $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
                                </div>
                            </form>
                        <?php else: ?>
                            <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92 = $attributes; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['label' => 'SIGN IN','href' => ''.e(route('login')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white hover:text-main font-medium']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $attributes = $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                </nav>
            </div>
        </div>

        <section>
            <?php echo e($slot); ?>

        </section>
    </div>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\PROJECTS\LaundrySystem\resources\views/components/user-layout.blade.php ENDPATH**/ ?>