<div>
    <h1 class="font-bold text-2xl text-gray-700">TOTAL SALES: &#8369;{{ number_format($sales_total_amount, 2) }}</h1>
    <div class="mt-3">
        {{ $this->table }}
    </div>
</div>
