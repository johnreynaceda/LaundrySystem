@section('title', 'Services')
<x-admin-layout>
    <div class="bg-white p-6  rounded-xl ">
        <livewire:admin.service-list />
    </div>
</x-admin-layout>
