<div class="ml-3">
    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\BookingTransaction::where('booking_id', $getRecord()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item->service->name); ?> x <?php echo e($item->quantity); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\LaundrySystem\resources\views/filament/tables/columns/services.blade.php ENDPATH**/ ?>