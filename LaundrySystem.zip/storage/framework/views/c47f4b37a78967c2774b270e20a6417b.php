<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\LaundrySystem\resources\views/livewire/status-list.blade.php ENDPATH**/ ?>