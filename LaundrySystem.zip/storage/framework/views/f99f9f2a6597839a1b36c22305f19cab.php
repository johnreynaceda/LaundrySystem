<div class="h-16 ml-3 ">
    <a href="<?php echo e(Storage::url($getRecord()->proof_of_payment)); ?>" target="_blank">
        <img src="<?php echo e(Storage::url($getRecord()->proof_of_payment)); ?>" class="h-16 object-cover w-16" alt="">
    </a>
</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\LaundrySystem\resources\views/filament/tables/columns/payment.blade.php ENDPATH**/ ?>