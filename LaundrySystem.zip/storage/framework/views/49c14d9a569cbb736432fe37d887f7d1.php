<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\LaundrySystem\resources\views/livewire/admin/service-list.blade.php ENDPATH**/ ?>