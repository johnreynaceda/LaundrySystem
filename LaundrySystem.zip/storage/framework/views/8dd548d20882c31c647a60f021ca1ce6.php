<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\LaundrySystem\resources\views/livewire/customer-list.blade.php ENDPATH**/ ?>