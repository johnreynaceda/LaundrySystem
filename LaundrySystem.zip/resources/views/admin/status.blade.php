@section('title', 'Status')
<x-admin-layout>
    <div class="bg-white p-6 rounded-xl">
        <livewire:status-list />
    </div>
</x-admin-layout>
