<div class="h-16 ml-3 ">
    <a href="{{ Storage::url($getRecord()->proof_of_payment) }}" target="_blank">
        <img src="{{ Storage::url($getRecord()->proof_of_payment) }}" class="h-16 object-cover w-16" alt="">
    </a>
</div>
