<x-user-layout>
    <div class="mx-auto max-w-7xl mt-10">
        <header class="font-bold text-main text-2xl">SERVICES AVAILABLE</header>
        <div class="mt-5">
            <livewire:transaction />
        </div>
    </div>
</x-user-layout>
